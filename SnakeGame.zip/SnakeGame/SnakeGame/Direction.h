#pragma once

//An enumerator class used to detect movement
enum class Direction { STOP = 0, LEFT = 1, RIGHT = 2, UP = 3, DOWN = 4 };