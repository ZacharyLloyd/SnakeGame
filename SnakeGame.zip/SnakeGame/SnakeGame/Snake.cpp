#include "Snake.h"
#include "Input.h"
#include <iostream>

using namespace std;
//The snake is symbolized as a 'O'
void Snake::CreateSnake()
{
	//On construction, print the snake
	tail.push_back(Tail());
	cout << tail[0].tail;
}

void Snake::AddTail() {
	tail.push_back(Tail());
}