#pragma once
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

class Tail
{
public:
	string tail = "O";
	int x, y;
};

class Snake
{
public:
	//Create the snake onto the board
	void CreateSnake();
	void AddTail();
	vector<Tail> tail;
	int x, y;
	unsigned int length;
private: 

protected:
	
};

