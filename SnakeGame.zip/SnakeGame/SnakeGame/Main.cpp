#include <iostream>
#include <string>
#include "Gameloop.h"
#include "Menu.h"
#include "Snake.h"

using namespace std;

GameLoop gameloop;

int main()
{
	gameloop.Run();
	return 0;
}